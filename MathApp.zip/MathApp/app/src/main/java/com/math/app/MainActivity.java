package com.math.app;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.view.View;

import android.view.Menu;
import android.view.MenuItem;

public class MainActivity extends AppCompatActivity {

    String name;

    EditText nameInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button start = (Button) findViewById(R.id.button);
        nameInput = (EditText) findViewById(R.id.name);

        start.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                name = nameInput.getText().toString();

                Intent myIntent = new Intent(v.getContext(), SecondFragment.class);
                startActivityForResult(myIntent, 0);

                showToast("Let's Go " + name);

            }
        });
    }

    private void showToast(String text){
        Toast.makeText(MainActivity.this, text, Toast.LENGTH_LONG ).show();
    }

}